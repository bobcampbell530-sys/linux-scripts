# read-highlighted.sh

A one-shot text-to-speech tool for Linux desktops. Highlight any text on your screen with your mouse, run the script, and hear it read aloud.

## What It Does

1. **Asks for speed** — prompts for a reading speed (or accepts the default).
2. **Reads it aloud** — uses Piper TTS to convert the text to speech.
3. **Exits** — closes the terminal window that it ran in.

## How It Works

- Detects text in your **primary selection** (what you highlight with mouse, not what you Ctrl+A copy).
- Skips selections shorter than 5 characters.
- Cleans up the text (removes extra spaces and newlines).
- Uses Piper TTS with your chosen voice model.
- Generates a temporary `.wav` file at `/tmp/piper_audio.wav` and deletes it after playback.
- Auto-closes the terminal window when done.

## Dependencies

| Package | Provides |
|---------|----------|
| `xclip` | Reading the highlighted selection |
| `piper` | Text-to-speech engine |
| `mpv` | Audio playback |
| `xdotool` | Auto-closing the terminal window |

Install:
```bash
sudo apt install xclip mpv xdotool
# Plus Piper TTS — see https://github.com/rhasspy/piper
```

## Usage

Run from terminal, launcher, or keyboard shortcut:
```bash
read-highlighted.sh
```

1. Highlight text on screen with your mouse.
2. Run the script.
3. Press Enter (default speed) or type a number to adjust speed.
   - Enter `7` for default speed (0.7x).
   - Enter `5` for slower (0.5x), `10` for normal (1.0x).

## Voices

The default voice is `hfc_male` (medium quality). Change the `VOICE_MODEL` variable in the script to use another:

| Voice | File |
|-------|------|
| hfc_male | `en_US-hfc_male-medium.onnx` |
| bryce | `en_US-bryce-medium.onnx` |
| joe | `en_US-joe-medium.onnx` |
| norman | `en_US-norman-medium.onnx` |
| sam | `en_US-sam-medium.onnx` |

Voice models are stored in `~/.local/share/piper-voices/`.

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `DEFAULT_SPEED_INT` | 7 | Integer input → divided by 10 → 0.7 |
| `MIN_LENGTH` | 5 | Minimum characters to ignore noise selections |

## What It's Good For

- Reading a selected paragraph quickly without interrupting your workflow
- Accessible browsing for visually impaired users
- Reading error messages or logs while doing something else