# launcher_v3.sh

A graphical launcher-creation and management tool for Linux desktops. Lets you create `.desktop` launchers from any executable script, manage (edit/delete) existing ones, and optionally place shortcuts on your desktop.

## What It Does

- **Edit existing:** Pick a `.desktop` file and open it in your preferred editor (xed, gedit, or nano).
- **Delete existing:** Select and remove a `.desktop` file with a confirmation dialog.
- **Create new launcher:** Step-by-step wizard that:
  1. Lets you select any executable script (`.sh`, `.py`, `.bash`, `.pl`, `.js`, `.rb`, `.perl`, `.lua`, `.tcl`).
  2. Asks for a **command name** (used for the symlink in `~/bin`, lowercase, no spaces).
  3. Asks for a **menu display name** (shown in your application menu, e.g. Cinnamenu).
  4. Asks for an optional **short description** (shown under the icon in the menu).
  5. Copies the script to `~/bin/utils/` (if not already there) and makes it executable.
  6. Creates a symlink `~/bin/<command-name>` → the script.
  7. Lets you pick an optional icon (PNG, SVG, ICO). Falls back to `utilities-terminal`.
  8. Creates a `.desktop` file in `~/.local/share/applications/`.
  9. Optionally copies the `.desktop` file to your Desktop folder.
  10. Updates the desktop database so the new launcher appears in menus immediately.

## Directory Structure

| Path | Purpose |
|------|---------|
| `~/bin/` | Symlinks for terminal commands |
| `~/bin/utils/` | Actual script files |
| `~/.local/share/applications/` | `.desktop` launcher files |
| `~/Icons/launchers/` | Custom icons for launchers |

## Dependencies

| Package | Provides |
|---------|----------|
| `zenity` | GUI dialogs |
| `update-desktop-database` | Desktop database update |

## Usage

Run from terminal or create a launcher for it:
```bash
launcher_v3.sh
```

## How It Works

1. Scans `~/.local/share/applications/*.desktop` for existing launchers.
2. Presents a two-column Zenity list (Action / Type).
3. For creation, walks through 7 input prompts using Zenity.
4. Uses `cat > file <<EOL` heredoc to generate the `.desktop` file.
5. Calls `update-desktop-database` to refresh the application menu.
