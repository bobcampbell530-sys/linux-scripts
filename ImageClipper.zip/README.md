# ImageClipper.sh

A GUI screenshot tool for Linux desktops (X11/Cinnamon). Prompts the user to select a screen region with the mouse, then saves the capture either to the clipboard or as a PNG file.

## What It Does

1. Asks **Clipboard** or **File** via a Zenity dialog.
2. Opens a crosshair cursor — click and drag to select a rectangle.
3. **Clipboard:** Copies the PNG directly to the clipboard (paste-ready).
4. **File:** Saves as `~/Pictures/Screenshots/YYYY-MM-DD_HHMMSS.png` and shows a notification.

## Dependencies

| Package | Provides |
|---------|----------|
| `imagemagick` | `import` command (region selection) |
| `xclip` | Clipboard operations |
| `zenity` | GUI dialogs |
| `libnotify-bin` | `notify-send` notifications |

Install:
```bash
sudo apt install imagemagick xclip zenity libnotify-bin
```

## Usage

Run from terminal, launcher, or keyboard shortcut:
```bash
ImageClipper.sh
```

## How It Works

- `import png:-` from ImageMagick opens an interactive region selector and outputs PNG to stdout.
- Piped to `xclip -selection clipboard -t image/png` for clipboard storage.
- For file mode, the timestamped filename is created in `~/Pictures/Screenshots/`.
- A notification confirms completion.
