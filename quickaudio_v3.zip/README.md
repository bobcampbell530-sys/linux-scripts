# quickaudio_v3.sh

A GUI audio recorder for Linux desktops (Mint X11, Cinnamon, etc.). Records system audio, microphone, or a mix as MP3 files. Run the script again to stop the recording.

## What It Does

1. Checks if a recording is already running — if so, sends SIGINT to gracefully stop ffmpeg and close the MP3 file.
2. If not running, walks through a setup wizard:
   - **Optional timer** — set a duration (minutes + seconds) or record manually.
   - **Audio source** — choose what to record.
   - **Optional filename** — name the output file or accept the default timestamped name.
3. Starts `ffmpeg` in the background to record audio as MP3 (192 kbps).
4. Saves to `~/Video/Audio/`.
5. Sends notifications at start and completion.

## Audio Source Options

| Option | Records |
|--------|---------|
| System audio only | All desktop/system sounds |
| Microphone only | Your microphone input |
| Both system + microphone | Mix of desktop audio and mic (via `amix` filter) |
| BX29 headphones | Audio from your BX29 Bluetooth headphones |

## Dependencies

| Package | Provides |
|---------|----------|
| `ffmpeg` | Audio recording and MP3 encoding |
| `zenity` | GUI dialogs |
| `pulseaudio-utils` | `pactl` for audio source discovery |
| `libnotify-bin` | `notify-send` notifications |

Install:
```bash
sudo apt install ffmpeg zenity pulseaudio-utils libnotify-bin
```

## Usage

Run from terminal or create a launcher for it:
```bash
quickaudio_v3.sh
```

To stop a running recording, run it again:
```bash
quickaudio_v3.sh
```

## How It Works

### PID-based toggle
- Stores the ffmpeg PID in `/tmp/quickaudio.pid`.
- First run: starts recording, writes PID.
- Second run: finds the PID, sends SIGINT (Ctrl+C) to ffmpeg, which flushes and closes the file.

### Audio source detection
- Uses `pactl list sinks short | grep RUNNING` to find the active system sink.
- Appends `.monitor` to the sink name to get the system audio monitor source.
- For BX29 headphones, searches `pactl` output for the device name or MAC address.

### Mixing system + mic
- Captures two inputs (`-i` twice) and applies an `amix` filter:
  ```
  -filter_complex "amix=inputs=2:duration=shortest:dropout_transition=2"
  ```

### Timer support
- If minutes or seconds are entered, wraps ffmpeg with `-t <seconds>` to auto-stop.

### Environment fixes
- Reads the desktop session's environment from `/proc/$SESSION_PID/environ` to ensure `DBUS_SESSION_BUS_ADDRESS`, `DISPLAY`, etc. are available when launched from a menu or launcher.

## Output

Files are saved as `~/Video/Audio/QuickAudio-YYYYMMDD-HHMMSS.mp3` or `~/Video/Audio/<custom-name>.mp3`.
