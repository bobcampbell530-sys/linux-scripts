# ocr_multi.sh

A GUI OCR (Optical Character Recognition) tool that captures a screen region and extracts text using Tesseract. The result is copied to the clipboard automatically.This is useful for extracting text from images and even handwritten text in images.

## What It Does

1. Prompts you to select an **OCR language** via Zenity (English, Spanish, French, German, Italian, Portuguese). This was added so that characters unique to these languages will be understood.
2. Opens a region selector (`gnome-screenshot -a`) — click and drag to choose the text area.
3. Runs **Tesseract OCR** on the captured region.
4. Copies the extracted text to the clipboard.
5. Shows a notification when done.

## Dependencies

| Package | Provides |
|---------|----------|
| `tesseract-ocr` + language packs | Tesseract OCR engine |
| `gnome-screenshot` | Region screenshot capture |
| `xclip` | Clipboard operations |
| `zenity` | GUI dialog |
| `libnotify-bin` | `notify-send` notifications |

Install:
```bash
sudo apt install tesseract-ocr tesseract-ocr-eng tesseract-ocr-spa tesseract-ocr-fra tesseract-ocr-deu tesseract-ocr-ita tesseract-ocr-por gnome-screenshot xclip zenity libnotify-bin
```

## Supported Languages

| Code | Language |
|------|----------|
| `eng` | English |
| `spa` | Spanish |
| `fra` | French |
| `deu` | German |
| `ita` | Italian |
| `por` | Portuguese |

Additional languages can be added to the `zenity --list` command by adding more `--column` entries and corresponding Tesseract language packs.

## Usage

Run from terminal or create a launcher for it:
```bash
ocr_multi.sh
```

## How It Works

1. `zenity --list --column "Code" eng spa fra deu ita por` — single-column list returns only the selected language code.
2. `gnome-screenshot -a -f /tmp/ocr_multi.png` — area-select screenshot saved to temp.
3. `tesseract /tmp/ocr_multi.png /tmp/ocr_multi_output -l "$LANG_CODE"` — runs OCR.
4. `xclip -selection clipboard < /tmp/ocr_multi_output.txt` — copies result to clipboard.
